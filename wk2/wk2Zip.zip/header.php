
<a href="viewActors.php">View Actors</a>&nbsp;&nbsp;&nbsp;
<a href="addActor.php">Add Actor</a>
        
