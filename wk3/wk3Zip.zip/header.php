
<a href="view-action.php">View Page</a>&nbsp;&nbsp;&nbsp;
<a href="addCorp.php">Add Page</a>
<a href="view-action-bootstrap.php">View Bootstrap</a>
        
